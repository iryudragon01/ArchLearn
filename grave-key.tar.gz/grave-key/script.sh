cp -rf ./rules/* /usr/share/X11/xkb/rules/
cp -rf ./symbols/* /usr/share/X11/xkb/symbols/
cp -rf ./xkb/* /etc/X11/xkb/
